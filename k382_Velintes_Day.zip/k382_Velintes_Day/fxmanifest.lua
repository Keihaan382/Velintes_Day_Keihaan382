fx_version "cerulean"
game "gta5"

this_the_map "yes"

PrincipalDescription "This resource has been created upon request and exclusively by the FiveM - Nevermore server - it will be respected as such forever."
Description "This resource contains vanilla file modifications - they do not affect any map type in the game-"
Description2 "This resource contains models - animation fisica - uv animation - the resource is fully optimized and 99% tested-"
Description3 "This resource does not conflict with any type of map"
Contact "@keihaan382 All Socials Media - https://linktr.ee/keihaan382 - Discord: https://discord.com/invite/CaNzpjZ7nS "

Grateful "The creator thanks Nevermore for the absolute trust placed in him to realize his work."

