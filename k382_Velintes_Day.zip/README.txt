# Velintes_Day_Keihaan382
Personalized models for Valentine's Day decoration.

**Decorate the city a little with these love models** 
This ymaps with customized models is located on a small beach in front of the lighthouse.
Invite that person who deserves to see a unique sunrise by candlelight.
Enjoy a chat with that special someone on the rainbow floats. 
It may be the beginning of a story with a happy ending.

• Pergola
• Bag
• Pillow
• Deck
• Curt
• Float
• Balloon
• Stair
• Candle

Important: This work © 2024 by keihaan382 is licensed under Attribution-ShareAlike 4.0 International 
